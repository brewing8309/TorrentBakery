"""Publish a baked release: build the tracker-specific torrent, post it to the tracker, hand it to qBittorrent."""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field, replace
from pathlib import Path

import httpx
from jinja2 import StrictUndefined
from jinja2.sandbox import SandboxedEnvironment
from torf import Torrent

from .clients import QbitError, QBittorrent, map_save_path
from .config import Config, Tracker
from .hosts import get_uploader
from .media.artwork import make_artwork
from .media.torrent import make_torrent
from .models import credited_performers
from .tags import TagMap, empify
from .trackers import PublishRequest, TrackerError, get_publisher, get_template

DEFAULT_TITLE = ("{% if studio %}[{{ studio }}] {% endif %}{% if performers %}{{ performers_text }} - {% endif %}{{ title }} "
                 "{% if date %}({{ date }}) {% endif %}[{{ resolution }}]")
RESOLUTIONS = (144, 240, 360, 480, 540, 720, 1080, 1440, 2160, 4320)


@dataclass
class Prepared:
    tracker: str
    title: str
    description: str
    tags: list[str]
    category: str
    image: str
    torrent: Path
    suggestions: dict[str, str] = field(default_factory=dict)  # unknown stash tag -> proposed tracker tag
    meta: dict = field(default_factory=dict)


def _resolution(media: dict) -> str:
    h = max(media.get("height", 0), round(media.get("width", 0) * 9 / 16))
    return f"{max((r for r in RESOLUTIONS if r <= h * 1.02), default=h)}p"


def _performers_text(names: list[str]) -> str:
    return names[0] if len(names) == 1 else " & ".join(names) if len(names) == 2 else ", ".join(names[:-1]) + " & " + names[-1] if names else ""


def render_title(template: str, release: dict, media: dict) -> str:
    env = SandboxedEnvironment(undefined=StrictUndefined, autoescape=False)
    perf = credited_performers(release)  # male performers are named neither in the title nor in the tags
    return " ".join(env.from_string(template or DEFAULT_TITLE).render(
        studio=release.get("studio", ""), performers=perf, performers_text=_performers_text(perf), title=release.get("title", ""),
        date=release.get("date", ""), resolution=_resolution(media), codec=media.get("video_codec", ""),
        duration=media.get("duration", 0), framerate=media.get("fps", 0)).split())


def performer_tags(release: dict) -> list[str]:
    return [t for t in (empify(p) for p in credited_performers(release)) if t]


def _mediainfo(out_dir: Path) -> str:
    try:
        return (out_dir / "mediainfo.txt").read_text()
    except OSError:
        return ""


def _read_meta(out_dir: Path) -> dict:
    try:
        return json.loads((out_dir / "release.json").read_text())
    except (OSError, ValueError) as e:
        raise TrackerError(f"{out_dir} holds no bake (release.json missing or damaged)") from e


def _content_path(out_dir: Path, meta: dict, torrent: Path) -> Path:
    """What the torrent hashes: the file or folder next to which the release lives."""
    if meta.get("content_path") and Path(meta["content_path"]).exists():
        return Path(meta["content_path"])
    name = Torrent.read(torrent).name  # bakes made before content_path was recorded
    folder = Path(meta.get("folder_path", ""))
    for cand in (folder / name, folder.parent / name):
        if cand.exists():
            return cand
    raise TrackerError(f"cannot find the media for {name!r} (looked in {folder}); is the share mounted?")


def _matches(torrent: Path, t: Tracker) -> bool:
    try:
        tor = Torrent.read(torrent)
    except Exception:
        return False
    announces = {u for tier in tor.trackers for u in tier}
    return bool(t.announce) and announces == set(t.announce) and (tor.source or "") == t.effective_source and bool(tor.private) == t.private


def prepare(cfg: Config, out_dir: Path, name: str, *, title: str | None = None, tags: list[str] | None = None, category: str | None = None, description: str | None = None,
            tagmap: TagMap | None = None, build_torrent: bool = True, progress=None) -> Prepared:
    t = cfg.trackers.get(name)
    if t is None:
        raise KeyError(f"unknown tracker profile {name!r}")
    if not t.announce:
        if not (t.template and t.template.engine == "unit3d"):
            raise TrackerError(f"tracker {name!r} has no announce URL (tb tracker fetch-announce {name})")
        t = replace(t, announce=[t.effective_base_url + "/announce"])  # UNIT3D rewrites the announce with your passkey on upload; any URL will do
    meta = _read_meta(out_dir)
    release, media = meta["release"], meta["media"]
    suggestions: dict[str, str] = {}
    if tags is None:
        mapped, suggestions = (tagmap or TagMap.load()).map_tags(release.get("tags", []), name)
        tags = mapped
    tags = list(dict.fromkeys(performer_tags(release) + tags))  # performers are always tagged, first, also when the tag field was edited by hand
    base = next(iter(sorted(out_dir.glob("*.torrent"), key=lambda p: ".tracker." in p.name)), None)
    if base is None:
        raise TrackerError(f"{out_dir} holds no .torrent")
    torrent = out_dir / f"{base.stem.split('.tracker.')[0]}.tracker.{name}.torrent"
    if not build_torrent:
        torrent = next((p for p in (torrent, base) if p.exists()), base)
    elif not (torrent.exists() and _matches(torrent, t)):
        if _matches(base, t):
            torrent = base
        else:
            make_torrent(_content_path(out_dir, meta, base), torrent, Tracker(t.announce, t.effective_source, t.private), progress)
    image = (meta.get("uploads", {}).get("cover") or {}).get("direct_url", "")
    return Prepared(name, title or render_title(t.title_template, release, media), description or (out_dir / "post.bbcode").read_text(), tags, category or t.category,
                    image, torrent, suggestions, meta)


def _seed(cfg: Config, out_dir: Path, name: str, torrent_id: str, local: Path, meta: dict, pub, qbit_transport, step) -> tuple[dict, dict]:
    """Fetch the torrent the tracker serves for `torrent_id` and add it to qBittorrent. Returns (qbit result, infohashes).
    Seeds the tracker's file, not our local one: the tracker rewrites uploads, which can change the infohash."""
    hashes: dict = {}
    try:
        step("Fetching the tracker's torrent")
        got = out_dir / f"{local.name.split('.tracker.')[0].removesuffix('.torrent')}.tracker.{name}.downloaded.torrent"  # ".tracker." keeps it from being taken for the base torrent
        got.write_bytes(pub.download_torrent(torrent_id))
        tor = Torrent.read(got)
        hashes = {"tracker": tor.infohash, "local": Torrent.read(local).infohash}
        step("Adding to qBittorrent")
        content = _content_path(out_dir, meta, local)
        state = QBittorrent(cfg.qbit, qbit_transport).add(got, tor.infohash, map_save_path(str(content.parent), cfg.qbit.path_map))
        note = "" if tor.infohash == hashes["local"] else " (the tracker changed the torrent, so its own file was used)"
        return {"ok": True, "message": f"added the tracker's torrent: {state}{note}"}, hashes
    except (QbitError, TrackerError, httpx.HTTPError, OSError, ValueError) as e:
        return {"ok": False, "message": f"nothing added to qBittorrent: {e}. Download the torrent from the tracker and add it yourself."}, hashes


def _artwork(cfg: Config, out_dir: Path, name: str, torrent_id: str, meta: dict, pub, transport, step) -> dict | None:
    """The list cover and banner of a UNIT3D torrent. Their edit form takes image URLs, so poster and banner are cut from the promo image,
    uploaded to the bake's image host and entered through the web form. The upload is public by now, so a failure is reported, not raised."""
    if not hasattr(pub, "set_artwork"):
        return None
    if not cfg.trackers[name].session_cookie:
        return {"ok": False, "message": "skipped: no web session cookie saved, so the list shows no cover and banner"}
    host = meta.get("image_host")
    if not host:
        return {"ok": False, "message": "skipped: this bake has no image-host upload, so there are no URLs for cover and banner"}
    try:
        step("Cutting cover and banner")
        poster, banner = make_artwork(cfg, out_dir, meta, transport)
        step("Uploading cover and banner to " + host)
        up = get_uploader(host, cfg)
        cover_url, banner_url = up.upload(poster, nsfw=True).direct_url, up.upload(banner, nsfw=True).direct_url
        step("Setting cover and banner")
        pub.set_artwork(torrent_id, cover_url, banner_url)
        return {"ok": True, "message": "cover and banner set", "cover_url": cover_url, "banner_url": banner_url}
    except (TrackerError, httpx.HTTPError, OSError, ValueError, KeyError) as e:
        return {"ok": False, "message": f"cover and banner not set: {e}"}


def set_artwork(cfg: Config, out_dir: Path, name: str, *, transport: httpx.BaseTransport | None = None, progress=None) -> dict:
    """Set cover and banner of an already published release again (e.g. after pasting a fresh web session cookie)."""
    f = out_dir / "publish.json"
    try:
        published = json.loads(f.read_text())[name]
    except (OSError, ValueError, KeyError):
        raise TrackerError(f"this release was not published on {name!r}")
    pub = get_publisher(name, cfg, transport)
    if not hasattr(pub, "set_artwork"):
        raise TrackerError(f"{name!r} has no separate cover and banner")
    result = _artwork(cfg, out_dir, name, published["torrent_id"], _read_meta(out_dir), pub, transport, progress or (lambda stage, frac=0.0: None))
    all_ = json.loads(f.read_text())
    all_[name]["artwork"] = result
    f.write_text(json.dumps(all_, indent=2, ensure_ascii=False))
    return result


def seed(cfg: Config, out_dir: Path, name: str, *, transport: httpx.BaseTransport | None = None, qbit_transport: httpx.BaseTransport | None = None, progress=None) -> dict:
    """Add an already published release to qBittorrent again (e.g. after fixing the qBittorrent settings). Returns the qBit result."""
    step = progress or (lambda stage, frac=0.0: None)
    if not cfg.qbit.url:
        raise QbitError("qBittorrent is not configured")
    f = out_dir / "publish.json"
    try:
        published = json.loads(f.read_text())[name]
    except (OSError, ValueError, KeyError):
        raise TrackerError(f"this release was not published on {name!r}")
    p = prepare(cfg, out_dir, name, build_torrent=False)
    result, hashes = _seed(cfg, out_dir, name, published["torrent_id"], p.torrent, p.meta, get_publisher(name, cfg, transport), qbit_transport, step)
    all_ = json.loads(f.read_text())
    all_[name].update({"qbit": result, "infohash": hashes})
    f.write_text(json.dumps(all_, indent=2, ensure_ascii=False))
    return result


def publish(cfg: Config, out_dir: Path, name: str, *, title: str | None = None, tags: list[str] | None = None, category: str | None = None, description: str | None = None,
            dry_run: bool = False, tagmap: TagMap | None = None, transport: httpx.BaseTransport | None = None,
            qbit_transport: httpx.BaseTransport | None = None, progress=None) -> dict:
    """Returns the result dict that is also stored in <out_dir>/publish.json (unless dry_run)."""
    step = progress or (lambda stage, frac=0.0: None)
    step("Preparing upload")
    p = prepare(cfg, out_dir, name, title=title, tags=tags, category=category, description=description, tagmap=tagmap, build_torrent=not dry_run,
                progress=lambda f: step("Hashing torrent", f))
    if not p.image and not dry_run:
        raise TrackerError("this bake has no image-host upload; the tracker needs a cover URL. Bake again with an image host.")
    pub = get_publisher(name, cfg, transport)
    step("Uploading to " + name)
    res = pub.publish(PublishRequest(p.torrent, p.title, p.description, p.tags, p.image, p.category, cfg.trackers[name].anonymous, mediainfo=_mediainfo(out_dir),
                                    resolution=int(_resolution(p.meta["media"]).rstrip("p") or 0)), dry_run=dry_run)
    out = {"tracker": name, "dry_run": dry_run, "title": p.title, "tags": p.tags, "category": p.category, "torrent": p.torrent.name,
           "torrent_url": res.torrent_url, "torrent_id": res.torrent_id, "sent": res.sent, "suggestions": p.suggestions, "qbit": None, "time": time.time()}
    if dry_run:
        return out
    # the upload is public from here on: a problem with cover/banner or qBittorrent is reported, never raised
    out["artwork"] = _artwork(cfg, out_dir, name, res.torrent_id, p.meta, pub, transport, step)
    if cfg.qbit.url:
        out["qbit"], out["infohash"] = _seed(cfg, out_dir, name, res.torrent_id, p.torrent, p.meta, pub, qbit_transport, step)
    f = out_dir / "publish.json"
    try:
        old = json.loads(f.read_text())
    except (OSError, ValueError):
        old = {}
    old[name] = {k: v for k, v in out.items() if k != "sent"}
    f.write_text(json.dumps(old, indent=2, ensure_ascii=False))
    return out
