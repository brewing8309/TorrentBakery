# Changelog

## 0.1.0 – unreleased
- Bake a release from a video file or a Stash scene: torrent, 5×7 screenshot sheet, main image, MediaInfo, BBCode forum post.
- Metadata from Stash and stash-box; image upload to pixhost (.to/.cc/pixho.st), imgbox, imagebam, hamsterimg.
- Animated cover (WebP/GIF) from 1.5-second clips spread over the video, or Stash's own preview.
- Web UI history that survives restarts; English interface with explained settings.
- Saved tracker profiles; CLI (`tb`) and web UI (`tb serve`).
- Publish to Gazelle trackers (Empornium, HappyFappy, FemdomCult, Enthralled) with a session cookie, add to qBittorrent, Stash→tracker tag mapping (default list from stash-empornium); `tb publish`, web UI publish section.
- Publish to UNIT3D trackers through their upload API (bitporn.eu): API token instead of a cookie, no announce URL needed.
- Review step between bake and upload in the web UI: category dropdowns with names everywhere, editable post, no upload without a chosen category.
- Image host imghost.dev (bitporn's own host) and a warning in the review step when a tracker cannot display the bake's image host.
- UNIT3D (bitporn) list cover and banner set through the edit form with a browser session cookie (the API cannot): poster and banner are cut, hosted on the bake's image host and entered as URLs; retry button on the result page.
- `tb` wrapper sets TB_CONFIG/TB_OUT like the service, so the CLI sees the saved profiles.
- qBittorrent: waits until the torrent is listed and checked, starts it only with complete files, confirms it is seeding (qBittorrent 5 left torrents "Completed"/stopped after the recheck).
- New visual design for the web UI: logo and favicon set, design tokens, self-hosted fonts, light and dark theme with a switch in the header, responsive layouts.
- Optional web login with TOTP two-factor authentication and recovery codes (scrypt password, in-memory sessions, throttling, CSRF check); `tb auth`.
- Settings: path mappings (Stash, qBittorrent) and the tag mapping use the same layout (table with Remove, Add row).
- Installable from a release tarball (`install.sh`, systemd service, `uninstall.sh`).
